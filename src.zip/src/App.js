import './App.css';
import GridApp from './Grid';

function App() {
  return (
    <div className="App">
      <GridApp/>
    </div>
  );
}

export default App;
